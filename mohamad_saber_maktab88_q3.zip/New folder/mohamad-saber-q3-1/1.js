 let a = document.getElementById('a') ;
a.style.backgroundColor = ``
function dark(){

    a.style.backgroundColor= 'blue'
}
function light(){
    a.style.backgroundColor = 'red'
}
