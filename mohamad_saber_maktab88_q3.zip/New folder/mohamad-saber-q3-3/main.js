const input = document.querySelector('input');
function updateValue() {
  input.value = input.value.replaceAll('.','_').replaceAll('-','_');
    console.log('aa')
}

