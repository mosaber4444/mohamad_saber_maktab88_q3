
let a = document.getElementById('myBar').style.width
function move() {
    if (a > 1 ){
        return ;
    }
    console.log(a)
    a = a + 10%
    // return a = a * 1.1 ;
}
// استاد من هر چی سعی کردم نتونستم مقدار درصد بهش اضافه کنم