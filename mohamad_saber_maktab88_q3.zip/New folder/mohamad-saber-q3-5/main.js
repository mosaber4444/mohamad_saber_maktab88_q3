let tehran = document.getElementById('tehran')
let tokyo = document.getElementById('tokyo')
let london = document.getElementById('london')

let input = document.getElementById('1')
let input2 = document.getElementById('2')


tehran.onclick = function () {
    input.innerHTML = 'tehran'
    input2.innerHTML = 'پایتخت ایران'
}


tokyo.onclick = function () {
    input.innerHTML = 'tokyo'
    input2.innerHTML = 'پایتخت ژاپن'
}

london.onclick = function () {
    input.innerHTML = 'london'
    input2.innerHTML = 'پایتخت انگلیس'
}